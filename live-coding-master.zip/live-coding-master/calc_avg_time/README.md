<h1>Calculate Average Time</h1>

<p>In this problem you are given the speed a train is travelling (x), and you are given the distance the train is travelling (y), you need to calculate how long it will take for the train to arrive at it's destination.

You will need to calculate the time for three trains, and then you will need to calculate the average time of the three trains journeys'.</p>

<h3>Example:</h3>

<p>Train One: x = 20, y = 150</p>
<p>time = 7.5</p>
<p>Train Two: x = 25, y = 155</p>
<p>time = 6.2</p>
<p>Train Three: x = 32, y = 162</p>
<p>time = 5.0625</p>
<p>Average for all three trains: average time = 6.25416</p>