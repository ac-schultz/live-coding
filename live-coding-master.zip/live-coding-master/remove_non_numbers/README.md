<h1>Remove Non Numbers</h1>

<p>In this problem you will be given a string. You will need to remove all the non numbers from the string. You will then need to multiply it by the length of the original string.</p>

<h3>Example:</h3>

<p>the_string = "19fe8 hxmi5"</p>
<p>the_string_only_numbers = "1985"</p>
<p>the_number = 1985</p>
<p>the_answer = 21835</p>