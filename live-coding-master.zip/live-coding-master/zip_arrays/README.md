<h1>Zip Arrays</h1>

<p>In this problem you are given 2 arrays of identical size. You need to zip the two arrays together maintaing their order.</p>

<h3>Example:</h3>

<p>array_one = [1, 5, 2]</p>
<p>array_two = [3, 6, 4]</p>
<p>zipped_array = [1, 3, 5, 6, 2, 4]</p>